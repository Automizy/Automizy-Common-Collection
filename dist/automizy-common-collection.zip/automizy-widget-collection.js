(function(){
    window.AutomizyWidgetCollection = window.$AWC = new function () {
        var t = this;
        t.version = '0.1.1';
        t.elements = {};
        t.dialogs = {};
        t.inputs = {};
        t.buttons = {};
        t.forms = {};
        t.functions = {};
        t.xhr = {};
        t.config = {
            dir:'.',
            url:'https://app.automizy.com'
        };
        t.m = {};
        t.d = {};
    }();
    return $AWC;
})();

(function(){
    var PluginLoader = function () {
        var t = this;
        t.d = {
            plugins: [],
            loadedPluginsCount: 0,
            completeFunctions: []
        };
    };

    var p = PluginLoader.prototype;


    p.addPlugin = function (plugin) {
        return this.addPlugins([plugin]);
    };

    p.plugins = p.addPlugins = function (plugins) {
        var t = this;
        if (typeof plugins !== 'undefined') {

            for (var i = 0; i < plugins.length; i++) {
                var plugin = plugins[i];
                plugin.skipCondition = plugin.skipCondition || false;
                plugin.complete = plugin.complete || function () {};
                plugin.css = plugin.css || [];
                plugin.js = plugin.js || [];

                if (typeof plugin.css === 'string') {
                    plugin.css = [plugin.css];
                }
                if (typeof plugin.js === 'string') {
                    plugin.js = [plugin.js];
                }
                t.d.plugins.push(plugin);
            }

            return t;
        }
        return t.d.plugins;
    };

    p.run = function () {

        var t = this;

        var hasActivePlugin = false;

        for (var i = 0; i < t.d.plugins.length; i++) {
            var plugin = t.d.plugins[i];
            if (plugin.inited) {
                continue;
            }
            plugin.inited = true;

            if (!plugin.skipCondition) {
                hasActivePlugin = true;
                for (var j = 0; j < plugin.css.length; j++) {
                    var head = document.getElementsByTagName('head')[0];
                    var link = document.createElement('link');
                    link.rel = 'stylesheet';
                    link.type = 'text/css';
                    link.href = plugin.css[j];
                    head.appendChild(link);
                }

                (function (plugin) {
                    var deferreds = [];

                    function pluginThen() {
                        t.d.loadedPluginsCount++;
                        plugin.complete.apply(this, []);
                        if (t.d.loadedPluginsCount === t.d.plugins.length) {
                            t.complete();
                        }
                    }

                    if (plugin.js.length <= 0) {
                        pluginThen();
                    } else {
                        for (var j = 0; j < plugin.js.length; j++) {
                            deferreds.push($.getScript(plugin.js[j]));
                        }
                        $.when.apply(null, deferreds).then(function () {
                            pluginThen();
                        });
                    }
                })(plugin);
            }else{
                plugin.complete.apply(this, []);
            }
        }

        if (!hasActivePlugin) {
            t.complete();
        }

        return t;
    };
    p.complete = function (complete) {
        var t = this;

        if (typeof complete === 'function') {
            t.d.completeFunctions.push({
                inited: false,
                func: complete
            });
            return t;
        }

        for (var i = 0; i < t.d.completeFunctions.length; i++) {
            if (t.d.completeFunctions[i].inited) {
                continue;
            }
            t.d.completeFunctions[i].inited = true;
            t.d.completeFunctions[i].func.apply(t, []);
        }

        return t;
    };

    $AWC.pluginLoader = new PluginLoader();

})();

(function(){

    $AWC.runTheFunctions = function(functions, thisParameter, parameters){
        var functions = functions || [];
        var thisParameter = thisParameter || $AWC;
        var parameters = parameters || [];
        for(var i = 0; i < functions.length; i++) {
            functions[i].apply(thisParameter, parameters);
        }
    };

})();

(function(){

    $AWC.functions.pluginsLoadedFunctions = [];
    $AWC.pluginsLoaded = function(f){
        if(typeof f === 'function'){
            $AWC.functions.pluginsLoadedFunctions.push(f);
            if($AWC.automizyPluginsLoaded){
                f.apply($AWC, []);
            }
            return $AWC;
        }
        $AWC.runTheFunctions($AWC.functions.pluginsLoadedFunctions, $AWC, []);
        $AWC.automizyPluginsLoaded = true;
        return $AWC;
    };

})();

(function(){
    $AWC.loadPlugins = function () {
        (function () {
            if (typeof window.jQuery === 'undefined') {
                var script = document.createElement("SCRIPT");
                script.src = $AWC.config.dir + "/vendor/jquery/jquery.min.js";
                script.type = 'text/javascript';
                document.getElementsByTagName("head")[0].appendChild(script);
            }
            var checkReady = function (callback) {
                if (typeof window.jQuery === 'function') {
                    callback(jQuery);
                } else {
                    window.setTimeout(function () {
                        checkReady(callback);
                    }, 100);
                }
            };

            checkReady(function ($) {
                $AWC.pluginLoader.plugins([
                    {
                        skipCondition:(function () {
                            var span = document.createElement('span');
                            span.className = 'fa';
                            span.style.display = 'none';
                            document.body.insertBefore(span, document.body.firstChild);
                            if (window.getComputedStyle(span, null).getPropertyValue('font-family') === 'FontAwesome') {
                                document.body.removeChild(span);
                                return true;
                            }
                            document.body.removeChild(span);
                            return false;
                        })(),
                        css:$AWC.config.dir + "/vendor/fontawesome/css/font-awesome.min.css"
                    },
                    {
                        skipCondition:typeof AutomizyJs !== 'undefined',
                        css:$AWC.config.dir + "/vendor/automizy-js/automizy.css",
                        js:[
                            $AWC.config.dir + '/vendor/automizy-js/languages/en_US.js',
                            $AWC.config.dir + "/vendor/automizy-js/automizy.js"
                        ],
                        complete:function(){
                            $A.setTranslate(window.I18N || {});
                        }
                    },
                    {
                        skipCondition:typeof AutomizyJsApi !== 'undefined',
                        js:$AWC.config.dir + "/vendor/automizy-js-api/automizy.api.js"
                    }
                ]).run().complete(function(){
                    $AWC.pluginsLoaded();
                });

            });

        })();
    };
})();

(function(){
    $AWC.init = function () {
        if(typeof $AWC.automizyInited === 'undefined'){
            $AWC.automizyInited = false;
        }

        if(!$AWC.automizyInited){
            $AWC.automizyInited = true;
            $AWC.loadPlugins();
        }

        return $AWC;
    };
})();

(function(){
    $AWC.baseDir = function(value){
        if (typeof value !== 'undefined') {
            $AWC.config.dir = value;
            return $AWC;
        }
        return $AWC.config.dir;
    };
})();

(function(){

    $AWC.functions.layoutReadyFunctions = [];
    $AWC.layoutReady = function(f){
        if(typeof f === 'function') {
            $AWC.functions.layoutReadyFunctions.push(f);
            if($AWC.automizyLayoutReady){
                f.apply($AWC, []);
            }
            return $AWC;
        }
        $AWC.runTheFunctions($AWC.functions.layoutReadyFunctions);
        $AWC.automizyLayoutReady = true;
        return $AWC;
    };

})();

(function(){

    $AWC.functions.readyFunctions = [];
    $AWC.ready = function(f){
        if(typeof f === 'function') {
            $AWC.functions.readyFunctions.push(f);
            if($AWC.automizyReady){
                f.apply($AWC, []);
            }
            return $AWC;
        }
        $AWC.runTheFunctions($AWC.functions.readyFunctions);
        $AWC.automizyReady = true;
        return $AWC;
    };

})();

(function(){
    $AWC.initChart = function (module, moduleName, moduleEvents) {
        var module = module || false;
        if (module === false) {
            return false;
        }
        var moduleName = moduleName || false;
        if (moduleName === false) {
            return false;
        }
        var moduleEvents = moduleEvents || [];

        var moduleNameLower = moduleName.toLowerCase();
        var moduleNameLowerFirst = moduleName.charAt(0).toLowerCase() + moduleName.slice(1);

        var p = module.prototype;
        p.init = p.init || function () {
                var t = this;
                t.d.$widget = $('<div class="automizy-chart-box"></div>');
                t.d.$title = $('<div class="automizy-chart-box-title"></div>').appendTo(t.d.$widget);
                t.d.$content = $('<div class="automizy-chart-box-content"></div>').appendTo(t.d.$widget);
                t.d.$icon = $('<div class="automizy-chart-box-content-icon"></div>').appendTo(t.d.$content);
                t.d.$chart = $('<div class="automizy-chart-box-content-chart"></div>').appendTo(t.d.$content);
                t.d.$description = $('<div class="automizy-chart-box-content-description"></div>').appendTo(t.d.$content);
                t.d.$more = $('<div class="automizy-chart-box-more"></div>').appendTo(t.d.$widget).click(function(){
                    var moreFunction = t.d.moreFunction || function(){};
                    moreFunction.apply(t, []);
                });
            };
        p.initParameter = p.initParameter || function (obj) {
                var t = this;
            };
        p.widget = p.widget || function () {
                return this.d.$widget;
            };

        p.drawAfter = p.insertAfter = p.drawAfter || function ($target) {
                var t = this;
                var $target = $target || $('body');
                return p.drawTo($target, 'after');
            };

        p.drawBefore = p.insertBefore = p.drawBefore || function ($target) {
                var t = this;
                var $target = $target || $('body');
                return p.drawTo($target, 'before');
            };
        p.drawTo = p.appendTo = p.drawTo || function ($target, where) {
                var t = this;
                var $target = $target || $AWC.$tmp;
                var where = where || 'in';
                var $elem = t.d.$widget;
                if (where === 'after') {
                    $elem.insertAfter($target);
                } else if (where === 'before') {
                    $elem.insertBefore($target);
                } else {
                    $elem.appendTo($target);
                }
                return t;
            };
        p.draw = p.drawTo || p.appendTo;

        p.show = p.show || function () {
                var t = this;
                t.d.$widget.addClass('automizy-hide');
                return t;
            };
        p.hide = p.hide || function (func) {
                var t = this;
                t.d.$widget.removeClass('automizy-hide');
                return t;
            };

        p.id = p.id || function (id) {
                var t = this;
                if (typeof id === 'number' || typeof id === 'string') {
                    t.d.$widget.attr('id', id);
                    t.d.id = id;
                    return t;
                }
                if (typeof t.d.id === 'undefined') {
                    t.d.id = t.widget().attr('id') || 'automizy-' + moduleNameLower + '-' + $A.getUniqueString();
                    t.id(t.d.id);
                }
                return t.d.id;
            };
        p.data = p.data || function (data, value) {
                var t = this;
                if (typeof t.d.data === 'undefined') {
                    t.d.data = {};
                }
                if (typeof data === 'undefined') {
                    return t.d.data;
                }
                if (typeof data === 'array' || typeof data === 'object') {
                    for (var i in data) {
                        t.d.data[i] = data[i];
                    }
                    return t;
                }
                if (typeof value === 'undefined') {
                    return t.d.data[data];
                }
                t.d.data[data] = value;
                return t;
            };
        p.returnValue = p.returnValue || function (value) {
                var t = this;
                if (typeof value !== 'undefined') {
                    t.d.returnValue = value;
                    return t;
                }
                return t.d.returnValue || null;
            };
        p.from = p.from || function (from) {
                var t = this;
                if (typeof from !== 'undefined') {
                    t.d.from = from;
                    if(t.d.from === false){
                        t.d.from = '-30 DAY';
                    }
                    return t;
                }
                return t.d.from || '-30 DAY';
            };
        p.to = p.to || function (to) {
                var t = this;
                if (typeof to !== 'undefined') {
                    t.d.to = to;
                    if(t.d.to === false){
                        t.d.to = 'NOW';
                    }
                    return t;
                }
                return t.d.to || 'NOW';
            };
        p.icon = p.icon || function(icon, iconType){
                var t = this;
                if (typeof icon !== 'undefined') {
                    t.d.icon = icon;
                    if(t.d.icon === false){
                        t.widget().removeClass('automizy-has-icon');
                    }else if(t.d.icon === true){
                        t.widget().addClass('automizy-has-icon');
                    }else{
                        t.widget().addClass('automizy-has-icon');
                        var iconType = iconType || 'fa';
                        if (iconType === 'fa') {
                            t.d.$icon.removeClass(function (index, css) {
                                return (css.match(/(^|\s)fa-\S+/g) || []).join(' ');
                            }).addClass('fa').addClass(icon);
                        }
                    }
                    return t;
                }
                return t.d.icon || false;
            };
        p.title = p.title || function (title) {
                var t = this;
                if (typeof title !== 'undefined') {
                    t.d.title = title;
                    if(t.d.title === false){
                        t.widget().removeClass('automizy-has-title');
                    }else if(t.d.title === true){
                        t.widget().addClass('automizy-has-title');
                    }else{
                        t.widget().addClass('automizy-has-title');
                        t.d.$title.html(t.d.title);
                    }
                    return t;
                }
                return t.d.title || false;
            };
        p.more = p.more || function (text, func) {
                var t = this;
                if (typeof text !== 'undefined') {
                    t.d.more = text;
                    if(t.d.more === false){
                        t.widget().removeClass('automizy-has-more');
                    }else if(t.d.more === true){
                        t.widget().addClass('automizy-has-more');
                    }else{
                        t.widget().addClass('automizy-has-more');
                        t.d.moreFunction = func || function(){};
                        t.d.$more.html(t.d.more);
                    }
                    return t;
                }
                return t.d.more || false;
            };
        p.description = p.description || function (description) {
                var t = this;
                if (typeof description !== 'undefined') {
                    t.d.description = description;
                    if(t.d.description === false){
                        t.widget().removeClass('automizy-has-description');
                    }else if(t.d.description === true){
                        t.widget().addClass('automizy-has-description');
                    }else{
                        t.widget().addClass('automizy-has-description');
                        t.d.$description.html(t.d.description);
                    }
                    return t;
                }
                return t.d.description || false;
            };

        $AWC.m[moduleName] = module;
        $AWC.d[moduleNameLower + "s"] = {};
        $AWC["last" + moduleName] = false;
        $AWC["new" + moduleName] = function (obj) {
            var t = new module(obj);
            $AWC.d[moduleNameLower + "s"][t.id()] = t;
            $AWC["last" + moduleName] = t;
            return t;
        };
        $AWC["get" + moduleName] = function (id) {
            return $AWC.d[moduleNameLower + "s"][id];
        };
        $AWC["getAll" + moduleName] = function () {
            return $AWC.d[moduleNameLower + "s"];
        };
        $AWC[moduleNameLowerFirst] = function (obj) {
            if (typeof obj === 'undefined') {
                return $AWC["new" + moduleName]();
            } else if (typeof obj === 'string' || typeof obj === 'number') {
                return $AWC["get" + moduleName](obj) || $AWC["new" + moduleName]().id(obj);
            } else {
                if (obj instanceof HTMLElement) {
                    obj = $(obj);
                }
                if (obj instanceof jQuery) {
                    return $AWC["get" + moduleName](obj.attr('id')) || $AWC["new" + moduleName](obj);
                }
            }
            return $AWC["new" + moduleName](obj);
        };
    }
})();

(function(){
    var BulkEmailsSendingAmount = function () {
        var t = this;
        t.d = {
            value:false
        };
        t.init();

        t.d.$chart.html('loading...');
    };

    var p = BulkEmailsSendingAmount.prototype;

    p.recalculate = function(){
        var t = this;

        $AWC.xhr.bulkEmailsSendingAmount = $.ajax({
            url:$AA.u.base + '/campaigns/globalStatistics/sent',
            type:'GET',
            headers: {Authorization: 'Bearer ' + $AA.token().get()},
            data:{
                format:'total',
                from:t.from(),
                to:t.to()
            }
        }).done(function(data){
            t.d.value = data.total;
            t.d.$chart.html($A.numberFormat(t.d.value));
        });

        return $AWC.xhr.bulkEmailsSendingAmount;
    };

    $AWC.initChart(BulkEmailsSendingAmount, "BulkEmailsSendingAmount", []);

})();

(function(){
    var BulkEmailsUniqueOpen = function () {
        var t = this;
        t.d = {
            value:false
        };
        t.init();

        t.d.$chart.html('loading...');
    };

    var p = BulkEmailsUniqueOpen.prototype;

    p.recalculate = function(){
        var t = this;

        $AWC.xhr.bulkEmailsUniqueOpen = $.ajax({
            url:$AA.u.base + '/campaigns/globalStatistics/open',
            type:'GET',
            headers: {Authorization: 'Bearer ' + $AA.token().get()},
            data:{
                format:'total',
                from:t.from(),
                to:t.to()
            }
        }).done(function(data){
            t.d.value = data.total;
            if($AWC.xhr.bulkEmailsSendingAmount === 'undefined'){
                $AWC.newBulkEmailsSendingAmount();
            }
            $AWC.xhr.bulkEmailsSendingAmount.done(function(sendData){
                t.d.$chart.html($A.numberFormat(t.d.value / sendData.total * 100, 2) + '%');
            })
        });

        return $AWC.xhr.bulkEmailsUniqueOpen;
    };

    $AWC.initChart(BulkEmailsUniqueOpen, "BulkEmailsUniqueOpen", []);

})();

(function(){
    var BulkEmailsUniqueClick = function () {
        var t = this;
        t.d = {
            value:false
        };
        t.init();

        t.d.$chart.html('loading...');
    };

    var p = BulkEmailsUniqueClick.prototype;

    p.recalculate = function(){
        var t = this;

        $AWC.xhr.bulkEmailsUniqueClick = $.ajax({
            url:$AA.u.base + '/campaigns/globalStatistics/click',
            type:'GET',
            headers: {Authorization: 'Bearer ' + $AA.token().get()},
            data:{
                format:'total',
                from:t.from(),
                to:t.to()
            }
        }).done(function(data){
            t.d.value = data.total;
            if($AWC.xhr.bulkEmailsSendingAmount === 'undefined'){
                $AWC.newBulkEmailsSendingAmount();
            }
            $AWC.xhr.bulkEmailsSendingAmount.done(function(sendData){
                t.d.$chart.html($A.numberFormat(t.d.value / sendData.total * 100, 2) + '%');
            })
        });

        return $AWC.xhr.bulkEmailsUniqueClick;
    };

    $AWC.initChart(BulkEmailsUniqueClick, "BulkEmailsUniqueClick", []);

})();

(function(){
    var BulkEmailsUnsubscribe = function () {
        var t = this;
        t.d = {
            value:false
        };
        t.init();

        t.d.$chart.html('loading...');
    };

    var p = BulkEmailsUnsubscribe.prototype;

    p.recalculate = function(){
        var t = this;

        $AWC.xhr.bulkEmailsUnsubscribe = $.ajax({
            url:$AA.u.base + '/campaigns/globalStatistics/unsubscribe',
            type:'GET',
            headers: {Authorization: 'Bearer ' + $AA.token().get()},
            data:{
                format:'total',
                from:t.from(),
                to:t.to()
            }
        }).done(function(data){
            t.d.value = data.total;
            if($AWC.xhr.bulkEmailsSendingAmount === 'undefined'){
                $AWC.newBulkEmailsSendingAmount();
            }
            $AWC.xhr.bulkEmailsSendingAmount.done(function(sendData){
                t.d.$chart.html($A.numberFormat(t.d.value / sendData.total * 100, 2) + '%');
            })
        });

        return $AWC.xhr.bulkEmailsUnsubscribe;
    };

    $AWC.initChart(BulkEmailsUnsubscribe, "BulkEmailsUnsubscribe", []);

})();

(function(){
    var BulkEmailsBounce = function () {
        var t = this;
        t.d = {
            value:false
        };
        t.init();

        t.d.$chart.html('loading...');
    };

    var p = BulkEmailsBounce.prototype;

    p.recalculate = function(){
        var t = this;

        $AWC.xhr.bulkEmailsBounce = $.ajax({
            url:$AA.u.base + '/campaigns/globalStatistics/bounce',
            type:'GET',
            headers: {Authorization: 'Bearer ' + $AA.token().get()},
            data:{
                format:'total',
                from:t.from(),
                to:t.to()
            }
        }).done(function(data){
            t.d.value = data;
            if($AWC.xhr.bulkEmailsSendingAmount === 'undefined'){
                $AWC.newBulkEmailsSendingAmount();
            }
            $AWC.xhr.bulkEmailsSendingAmount.done(function(sendData){
                t.d.$chart.html($A.numberFormat(t.d.value.soft / sendData.total * 100, 2) + '%, ' + $A.numberFormat(t.d.value.hard / sendData.total * 100, 2) + '%');
            })
        });

        return $AWC.xhr.bulkEmailsBounce;
    };

    $AWC.initChart(BulkEmailsBounce, "BulkEmailsBounce", []);

})();

(function(){
    var BulkEmailsOverallDeliverability = function () {
        var t = this;
        t.d = {
            value:false
        };
        t.init();

        t.d.$chart.html('loading...');
    };

    var p = BulkEmailsOverallDeliverability.prototype;

    p.recalculate = function(){
        var t = this;

        if($AWC.xhr.bulkEmailsSendingAmount === 'undefined'){
            $AWC.newBulkEmailsSendingAmount();
        }
        if($AWC.xhr.bulkEmailsBounce === 'undefined'){
            $AWC.newBulkEmailsBounce();
        }
        $AWC.xhr.bulkEmailsSendingAmount.done(function(sendData){
            $AWC.xhr.bulkEmailsBounce.done(function(bounceData) {
                var bounceCount = bounceData.hard + bounceData.soft;
                t.d.$chart.html($A.numberFormat(100 - bounceCount / sendData.total * 100, 2) + '%');
            });
        });

        return $.when.apply(null, [$AWC.xhr.bulkEmailsSendingAmount, $AWC.xhr.bulkEmailsBounce]);
    };

    $AWC.initChart(BulkEmailsOverallDeliverability, "BulkEmailsOverallDeliverability", []);

})();

(function(){
    var AutomationsSendingAmount = function () {
        var t = this;
        t.d = {
            value:false
        };
        t.init();

        t.d.$chart.html('loading...');
    };

    var p = AutomationsSendingAmount.prototype;

    p.recalculate = function(){
        var t = this;

        $AWC.xhr.automationsSendingAmount = $.ajax({
            url:$AA.u.base + '/automations/globalstatistic/sent',
            type:'GET',
            headers: {Authorization: 'Bearer ' + $AA.token().get()},
            data:{
                format:'total',
                from:t.from(),
                to:t.to()
            }
        }).done(function(data){
            t.d.value = data.total;
            t.d.$chart.html($A.numberFormat(t.d.value));
        });

        return $AWC.xhr.automationsSendingAmount;
    };

    $AWC.initChart(AutomationsSendingAmount, "AutomationsSendingAmount", []);

})();

(function(){
    var AutomationsUniqueOpen = function () {
        var t = this;
        t.d = {
            value:false
        };
        t.init();

        t.d.$chart.html('loading...');
    };

    var p = AutomationsUniqueOpen.prototype;

    p.recalculate = function(){
        var t = this;

        $AWC.xhr.automationsUniqueOpen = $.ajax({
            url:$AA.u.base + '/automations/globalstatistic/open',
            type:'GET',
            headers: {Authorization: 'Bearer ' + $AA.token().get()},
            data:{
                format:'total',
                from:t.from(),
                to:t.to()
            }
        }).done(function(data){
            t.d.value = data.total;
            if($AWC.xhr.automationsSendingAmount === 'undefined'){
                $AWC.newAutomationsSendingAmount();
            }
            $AWC.xhr.automationsSendingAmount.done(function(sendData){
                t.d.$chart.html($A.numberFormat(t.d.value / sendData.total * 100, 2) + '%');
            })
        });

        return $AWC.xhr.automationsUniqueOpen;
    };

    $AWC.initChart(AutomationsUniqueOpen, "AutomationsUniqueOpen", []);

})();

(function(){
    var AutomationsUniqueClick = function () {
        var t = this;
        t.d = {
            value:false
        };
        t.init();

        t.d.$chart.html('loading...');
    };

    var p = AutomationsUniqueClick.prototype;

    p.recalculate = function(){
        var t = this;

        $AWC.xhr.automationsUniqueClick = $.ajax({
            url:$AA.u.base + '/campaigns/globalStatistics/click',
            type:'GET',
            headers: {Authorization: 'Bearer ' + $AA.token().get()},
            data:{
                format:'total',
                from:t.from(),
                to:t.to()
            }
        }).done(function(data){
            t.d.value = data.total;
            if($AWC.xhr.automationsSendingAmount === 'undefined'){
                $AWC.newAutomationsSendingAmount();
            }
            $AWC.xhr.automationsSendingAmount.done(function(sendData){
                t.d.$chart.html($A.numberFormat(t.d.value / sendData.total * 100, 2) + '%');
            })
        });

        return $AWC.xhr.automationsUniqueClick;
    };

    $AWC.initChart(AutomationsUniqueClick, "AutomationsUniqueClick", []);

})();

(function(){
    var AutomationsUnsubscribe = function () {
        var t = this;
        t.d = {
            value:false
        };
        t.init();

        t.d.$chart.html('loading...');
    };

    var p = AutomationsUnsubscribe.prototype;

    p.recalculate = function(){
        var t = this;

        $AWC.xhr.automationsUnsubscribe = $.ajax({
            url:$AA.u.base + '/automations/globalstatistic/unsubscribe',
            type:'GET',
            headers: {Authorization: 'Bearer ' + $AA.token().get()},
            data:{
                format:'total',
                from:t.from(),
                to:t.to()
            }
        }).done(function(data){
            t.d.value = data.total;
            if($AWC.xhr.automationsSendingAmount === 'undefined'){
                $AWC.newAutomationsSendingAmount();
            }
            $AWC.xhr.automationsSendingAmount.done(function(sendData){
                t.d.$chart.html($A.numberFormat(t.d.value / sendData.total * 100, 2) + '%');
            })
        });

        return $AWC.xhr.automationsUnsubscribe;
    };

    $AWC.initChart(AutomationsUnsubscribe, "AutomationsUnsubscribe", []);

})();

(function(){
    var AutomationsSubscriptionGraph = function () {
        var t = this;
        t.d = {
            value:false,
            chart:false,
            chartInited:false,
            $loading:$('<span></span>'),
            $canvas:$('<canvas></canvas>'),
            defaultChartData:{
                type: 'line',
                data: {
                    labels: [],
                    datasets: [
                        {
                            legend: $A.translate('Subscribes'),
                            data: []
                        }
                    ]
                },
                options: {
                    legend: {
                        display: false
                    },
                    scales: {
                        xAxes: [{
                            type: 'time'
                        }]
                    }
                }
            }
        };
        t.init();

        t.d.$loading.html('loading...').appendTo(t.d.$chart);
        t.d.$canvas.appendTo(t.d.$chart).hide();

    };

    var p = AutomationsSubscriptionGraph.prototype;

    p.refreshChart = function(){
        var t = this;

        var labels = [];
        var datas = [];
        var min = Number.MAX_VALUE;
        var max = 0;
        var interval = 0;
        for(var i = 0; i < t.d.value.length; i++){
            var value = t.d.value[i].value.subscribed;
            var date = t.d.value[i].date.date;
            if(min > value){
                min = value;
            }
            if(max < value){
                max = value;
            }
            labels.push(date);
            datas.push(value);

        }
        interval = max - min;

        if(interval < 7){
            t.d.chart.options.scales.yAxes[0].ticks.stepSize = 1;
        }else{
            t.d.chart.options.scales.yAxes[0].ticks.stepSize = null;
        }

        t.d.chart.data.labels = labels;
        t.d.chart.data.datasets[0].data = datas;
        t.d.chart.update();

        return t;
    };

    p.recalculate = function(){
        var t = this;

        $AWC.xhr.automationsSubscriptionGraph = $.ajax({
            url:$AA.u.base + '/forms/globalstatistic/subscribed',
            type:'GET',
            headers: {Authorization: 'Bearer ' + $AA.token().get()},
            data:{
                format:'timeline',
                from: t.from(),
                to: t.to(),
                forms:[]
            }
        }).done(function(data){
            t.d.value = data;

            if(t.d.chartInited) {
                t.refreshChart();
            }else{
                $AWC.pluginLoader.addPlugin({
                    skipCondition: typeof Chart !== 'undefined',
                    js: $AWC.config.dir + "/vendor/chartjs/Chart.bundle.js",
                    complete: function () {
                        t.d.chart = new Chart(t.d.$canvas, t.d.defaultChartData);
                        t.d.$loading.remove();
                        t.d.$canvas.show();
                        t.refreshChart();
                    }
                }).run();
            }
            t.d.chartInited = true;

        });

        return $AWC.xhr.automationsSubscriptionGraph;
    };

    p.defaultChartData = function(defaultChartData){
        var t = this;
        t.d.defaultChartData = defaultChartData;
        return t;
    };

    $AWC.initChart(AutomationsSubscriptionGraph, "AutomationsSubscriptionGraph", []);

})();

(function(){
    var AutomationsEmailsSendGraph = function () {
        var t = this;
        t.d = {
            value:false,
            chart:false,
            chartInited:false,
            $loading:$('<span></span>'),
            $canvas:$('<canvas></canvas>'),
            defaultChartData:{
                type: 'line',
                data: {
                    labels: [],
                    datasets: [
                        {
                            legend: $A.translate('Opens'),
                            data: []
                        }
                    ]
                },
                options: {
                    legend: {
                        display: false
                    },
                    scales: {
                        xAxes: [{
                            type: 'time'
                        }]
                    }
                }
            }
        };
        t.init();

        t.d.$loading.html('loading...').appendTo(t.d.$chart);
        t.d.$canvas.appendTo(t.d.$chart).hide();

    };

    var p = AutomationsEmailsSendGraph.prototype;

    p.refreshChart = function(){
        var t = this;

        var labels = [];
        var datas = [];
        var min = Number.MAX_VALUE;
        var max = 0;
        var interval = 0;
        for(var i = 0; i < t.d.value.length; i++){
            var value = t.d.value[i].value.contacts;
            var date = t.d.value[i].date.date;
            if(min > value){
                min = value;
            }
            if(max < value){
                max = value;
            }
            labels.push(date);
            datas.push(value);

        }
        interval = max - min;

        if(interval < 7){
            t.d.chart.options.scales.yAxes[0].ticks.stepSize = 1;
        }else{
            t.d.chart.options.scales.yAxes[0].ticks.stepSize = null;
        }

        t.d.chart.data.labels = labels;
        t.d.chart.data.datasets[0].data = datas;
        t.d.chart.update();

        return t;
    };

    p.recalculate = function(){
        var t = this;

        $AWC.xhr.automationsEmailsSendGraph = $.ajax({
            url:$AA.u.base + '/automations/globalstatistic/sent',
            type:'GET',
            headers: {Authorization: 'Bearer ' + $AA.token().get()},
            data:{
                format:'timeline',
                from: t.from(),
                to: t.to(),
                forms:[]
            }
        }).done(function(data){
            t.d.value = data;

            if(t.d.chartInited) {
                t.refreshChart();
            }else{
                $AWC.pluginLoader.addPlugin({
                    skipCondition: typeof Chart !== 'undefined',
                    js: $AWC.config.dir + "/vendor/chartjs/Chart.bundle.js",
                    complete: function () {
                        t.d.chart = new Chart(t.d.$canvas, t.d.defaultChartData);
                        t.d.$loading.remove();
                        t.d.$canvas.show();
                        t.refreshChart();
                    }
                }).run();
            }
            t.d.chartInited = true;

        });

        return $AWC.xhr.automationsEmailsSendGraph;
    };

    p.defaultChartData = function(defaultChartData){
        var t = this;
        t.d.defaultChartData = defaultChartData;
        return t;
    };

    $AWC.initChart(AutomationsEmailsSendGraph, "AutomationsEmailsSendGraph", []);

})();

(function(){
    var AutomationsEmailsOpenGraph = function () {
        var t = this;
        t.d = {
            value:false,
            chart:false,
            chartInited:false,
            $loading:$('<span></span>'),
            $canvas:$('<canvas></canvas>'),
            defaultChartData:{
                type: 'line',
                data: {
                    labels: [],
                    datasets: [
                        {
                            legend: $A.translate('Opens'),
                            data: []
                        }
                    ]
                },
                options: {
                    legend: {
                        display: false
                    },
                    scales: {
                        xAxes: [{
                            type: 'time'
                        }]
                    }
                }
            }
        };
        t.init();

        t.d.$loading.html('loading...').appendTo(t.d.$chart);
        t.d.$canvas.appendTo(t.d.$chart).hide();

    };

    var p = AutomationsEmailsOpenGraph.prototype;

    p.refreshChart = function(){
        var t = this;

        var labels = [];
        var datas = [];
        var min = Number.MAX_VALUE;
        var max = 0;
        var interval = 0;
        for(var i = 0; i < t.d.value.length; i++){
            var value = t.d.value[i].value.contacts;
            var date = t.d.value[i].date.date;
            if(min > value){
                min = value;
            }
            if(max < value){
                max = value;
            }
            labels.push(date);
            datas.push(value);

        }
        interval = max - min;

        if(interval < 7){
            t.d.chart.options.scales.yAxes[0].ticks.stepSize = 1;
        }else{
            t.d.chart.options.scales.yAxes[0].ticks.stepSize = null;
        }

        t.d.chart.data.labels = labels;
        t.d.chart.data.datasets[0].data = datas;
        t.d.chart.update();

        return t;
    };

    p.recalculate = function(){
        var t = this;

        $AWC.xhr.automationsEmailsOpenGraph = $.ajax({
            url:$AA.u.base + '/automations/globalstatistic/open',
            type:'GET',
            headers: {Authorization: 'Bearer ' + $AA.token().get()},
            data:{
                format:'timeline',
                from: t.from(),
                to: t.to(),
                forms:[]
            }
        }).done(function(data){
            t.d.value = data;

            if(t.d.chartInited) {
                t.refreshChart();
            }else{
                $AWC.pluginLoader.addPlugin({
                    skipCondition: typeof Chart !== 'undefined',
                    js: $AWC.config.dir + "/vendor/chartjs/Chart.bundle.js",
                    complete: function () {
                        t.d.chart = new Chart(t.d.$canvas, t.d.defaultChartData);
                        t.d.$loading.remove();
                        t.d.$canvas.show();
                        t.refreshChart();
                    }
                }).run();
            }
            t.d.chartInited = true;

        });

        return $AWC.xhr.automationsEmailsOpenGraph;
    };

    p.defaultChartData = function(defaultChartData){
        var t = this;
        t.d.defaultChartData = defaultChartData;
        return t;
    };

    $AWC.initChart(AutomationsEmailsOpenGraph, "AutomationsEmailsOpenGraph", []);

})();

(function(){
    var AutomationsEmailsClickGraph = function () {
        var t = this;
        t.d = {
            value:false,
            chart:false,
            chartInited:false,
            $loading:$('<span></span>'),
            $canvas:$('<canvas></canvas>'),
            defaultChartData:{
                type: 'line',
                data: {
                    labels: [],
                    datasets: [
                        {
                            legend: $A.translate('Clicks'),
                            data: []
                        }
                    ]
                },
                options: {
                    legend: {
                        display: false
                    },
                    scales: {
                        xAxes: [{
                            type: 'time'
                        }]
                    }
                }
            }
        };
        t.init();

        t.d.$loading.html('loading...').appendTo(t.d.$chart);
        t.d.$canvas.appendTo(t.d.$chart).hide();

    };

    var p = AutomationsEmailsClickGraph.prototype;

    p.refreshChart = function(){
        var t = this;

        var labels = [];
        var datas = [];
        var min = Number.MAX_VALUE;
        var max = 0;
        var interval = 0;
        for(var i = 0; i < t.d.value.length; i++){
            var value = t.d.value[i].value.contacts;
            var date = t.d.value[i].date.date;
            if(min > value){
                min = value;
            }
            if(max < value){
                max = value;
            }
            labels.push(date);
            datas.push(value);

        }
        interval = max - min;

        if(interval < 7){
            t.d.chart.options.scales.yAxes[0].ticks.stepSize = 1;
        }else{
            t.d.chart.options.scales.yAxes[0].ticks.stepSize = null;
        }

        t.d.chart.data.labels = labels;
        t.d.chart.data.datasets[0].data = datas;
        t.d.chart.update();

        return t;
    };

    p.recalculate = function(){
        var t = this;

        $AWC.xhr.automationsEmailsClickGraph = $.ajax({
            url:$AA.u.base + '/automations/globalstatistic/sent',
            type:'GET',
            headers: {Authorization: 'Bearer ' + $AA.token().get()},
            data:{
                format:'timeline',
                from: t.from(),
                to: t.to(),
                forms:[]
            }
        }).done(function(data){
            t.d.value = data;

            if(t.d.chartInited) {
                t.refreshChart();
            }else{
                $AWC.pluginLoader.addPlugin({
                    skipCondition: typeof Chart !== 'undefined',
                    js: $AWC.config.dir + "/vendor/chartjs/Chart.bundle.js",
                    complete: function () {
                        t.d.chart = new Chart(t.d.$canvas, t.d.defaultChartData);
                        t.d.$loading.remove();
                        t.d.$canvas.show();
                        t.refreshChart();
                    }
                }).run();
            }
            t.d.chartInited = true;

        });

        return $AWC.xhr.automationsEmailsClickGraph;
    };

    p.defaultChartData = function(defaultChartData){
        var t = this;
        t.d.defaultChartData = defaultChartData;
        return t;
    };

    $AWC.initChart(AutomationsEmailsClickGraph, "AutomationsEmailsClickGraph", []);

})();

(function(){
    var AutomationsEmailsSendOpenClickGraph = function () {
        var t = this;
        t.d = {
            sendValue:false,
            openValue:false,
            clickValue:false,
            chart:false,
            chartdata:[[],[],[]],
            chartInited:false,
            $loading:$('<span></span>'),
            $canvas:$('<canvas></canvas>'),
            defaultChartData:{
                type: 'line',
                data: {
                    labels: [],
                    datasets: [
                        {
                            legend: $A.translate('Sends'),
                            data: []
                        },
                        {
                            legend: $A.translate('Opens'),
                            data: []
                        },
                        {
                            legend: $A.translate('Clicks'),
                            data: []
                        }
                    ]
                },
                options: {
                    legend: {
                        display: false
                    },
                    scales: {
                        xAxes: [{
                            type: 'time'
                        }]
                    }
                }
            }
        };
        t.init();

        t.d.$loading.html('loading...').appendTo(t.d.$chart);
        t.d.$canvas.appendTo(t.d.$chart).hide();

    };

    var p = AutomationsEmailsSendOpenClickGraph.prototype;

    p.refreshChart = function(){
        var t = this;

        var labels = [];
        var datas = [[],[],[]];
        var min = Number.MAX_VALUE;
        var max = 0;
        var interval = 0;
        var value, date;

        for(var i = 0; i < t.d.sendValue.length; i++){
            value = t.d.sendValue[i].value.contacts;
            date = t.d.sendValue[i].date.date;
            if(min > value){
                min = value;
            }
            if(max < value){
                max = value;
            }
            labels.push(date);
            datas[0].push(value);
        }
        for(var i = 0; i < t.d.openValue.length; i++){
            value = t.d.openValue[i].value.contacts;
            if(min > value){
                min = value;
            }
            if(max < value){
                max = value;
            }
            datas[1].push(value);
        }
        for(var i = 0; i < t.d.clickValue.length; i++){
            value = t.d.clickValue[i].value.contacts;
            if(min > value){
                min = value;
            }
            if(max < value){
                max = value;
            }
            datas[2].push(value);
        }

        interval = max - min;

        if(interval < 7){
            t.d.chart.options.scales.yAxes[0].ticks.stepSize = 1;
        }else{
            t.d.chart.options.scales.yAxes[0].ticks.stepSize = null;
        }

        t.d.chart.data.labels = labels;
        t.d.chart.data.datasets[0].data = datas[0];
        t.d.chart.data.datasets[1].data = datas[1];
        t.d.chart.data.datasets[2].data = datas[2];
        t.d.chart.update();

        return t;
    };

    p.recalculate = function(){
        var t = this;

        if(typeof $AWC.xhr.automationsEmailsSendGraph === 'undefined'){
            $AWC.newAutomationsEmailsSendGraph().from(t.from()).to(t.to()).recalculate();
        }else{
            $AWC.lastAutomationsEmailsSendGraph.from(t.from()).to(t.to()).recalculate();
        }
        if(typeof $AWC.xhr.automationsEmailsOpenGraph === 'undefined'){
            $AWC.newAutomationsEmailsOpenGraph().from(t.from()).to(t.to()).recalculate();
        }else{
            $AWC.lastAutomationsEmailsOpenGraph.from(t.from()).to(t.to()).recalculate();
        }
        if(typeof $AWC.xhr.automationsEmailsClickGraph === 'undefined'){
            $AWC.newAutomationsEmailsClickGraph().from(t.from()).to(t.to()).recalculate();
        }else{
            $AWC.lastAutomationsEmailsClickGraph.from(t.from()).to(t.to()).recalculate();
        }

        $AWC.xhr.automationsEmailsSendGraph.done(function(sendData){
            t.d.sendValue = sendData;
            $AWC.xhr.automationsEmailsOpenGraph.done(function(openData) {
                t.d.openValue = openData;
                $AWC.xhr.automationsEmailsClickGraph.done(function(clickData) {
                    t.d.clickValue = clickData;

                    if(t.d.chartInited) {
                        t.refreshChart();
                    }else{
                        $AWC.pluginLoader.addPlugin({
                            skipCondition: typeof Chart !== 'undefined',
                            js: $AWC.config.dir + "/vendor/chartjs/Chart.bundle.js",
                            complete: function () {
                                t.d.chart = new Chart(t.d.$canvas, t.d.defaultChartData);
                                t.d.$loading.remove();
                                t.d.$canvas.show();
                                t.refreshChart();
                            }
                        }).run();
                    }
                    t.d.chartInited = true;
                });
            });
        });

        return $.when.apply(null, [$AWC.xhr.automationsEmailsSendGraph, $AWC.xhr.automationsEmailsOpenGraph, $AWC.xhr.automationsEmailsClickGraph]);
    };

    p.defaultChartData = function(defaultChartData){
        var t = this;
        t.d.defaultChartData = defaultChartData;
        return t;
    };

    $AWC.initChart(AutomationsEmailsSendOpenClickGraph, "AutomationsEmailsSendOpenClickGraph", []);

})();

(function(){
    $AWC.pluginsLoaded(function () {

        $AWC.$tmp = $('<div id="automizy-widget-collection-tmp"></div>');

        $AWC.layoutReady();
        $AWC.ready();
    });
})();

(function(){
    console.log('%c AutomizyWidgetCollection loaded! ', 'background: #000000; color: #bada55; font-size:14px');
})();

(function(){})();